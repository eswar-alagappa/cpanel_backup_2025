</div>
<div class="footerOuter">
<div class="footer">  
<div class="footerLeft">© Alagappa Performing Arts Academy. </div>
<div class="footerRight"><a href="http://sanjaytechnologies.org/" target="_blank">Developed by Sanjay Technologies</a></div>
</div>
</div>


</body>
</html>

