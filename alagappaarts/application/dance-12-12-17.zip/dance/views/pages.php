<div class="danceInnerContent">

 <?php $this->load->view('left_banner'); ?>
<!--<div class="danceInnerContentLeft"><div class="danceBannerLeft">
 <img title="apaa-banner-left.jpg" alt="apaa-banner-left.jpg" src="http://alagappaarts.com/dance/wp-content/header-images/apaa-banner-left.jpg">
</div>
<div class="danceLeftContent">
<div class="danceleftNav"><h2>About Apaa</h2>	<ul>
		<li class="page_item page-item-2261"><a href="http://alagappaarts.com/dance/about-apaa/university/"><span>University</span></a></li>
<li class="page_item page-item-2265"><a href="http://alagappaarts.com/dance/about-apaa/management/"><span>Management</span></a></li>
<li class="page_item page-item-2270"><a href="http://alagappaarts.com/dance/about-apaa/objective/"><span>Objective</span></a></li>
<li class="page_item page-item-2272"><a href="http://alagappaarts.com/dance/about-apaa/advisory-board/"><span>Advisory Board</span></a></li>
<li class="page_item page-item-2274"><a href="http://alagappaarts.com/dance/about-apaa/future-plans/"><span>Future Plans</span></a></li>
<li class="page_item page-item-2276"><a href="http://alagappaarts.com/dance/about-apaa/accreditation/"><span>Accreditation</span></a></li>
	</ul></div>
<div id="tabcourses" class="courses">
<h2>Programs</h2>
<ul>
<li><a href="http://alagappaarts.com/dance/academics/apaa-programs?0">Certificate</a></li>
<li><a href="http://alagappaarts.com/dance/academics/apaa-programs?1">Associate Degree</a></li>
<li><a href="http://alagappaarts.com/dance/academics/apaa-programs?2">Diploma</a></li>
<li><a href="http://alagappaarts.com/dance/academics/apaa-programs?3">Bachelor's Degree</a></li>
</ul>
</div>
<div class="news innerNews">
<h2>news</h2>
<p>Disciple of Smt.Deepali Vora &ndash; Nitya Shetra Dance School, completed her Arangetram successfully in Log Angeles, USA.</p>

</div>
</div>
</div>-->




    
<div class="danceInnerContentRight">
<div class="danceBanner">
<?php if($title!="demo") { ?>
<h2><span><?php echo $title; ?></span></h2>
<?php } ?>
<?php if($title=="demo") { ?>
<h2><span>FEATURED GURU</span></h2>
<?php } ?>
</div>

<?php if($title!="demo") { ?>
<?php   print_r($page);

?> 		
<!--<p>Alagappa Performing Arts Academy (APAA) an integral part of the Alagappa group of institutions was founded in 2005 by Mr. Ramanath Vairavan, grandson of Dr. RM. Alagappa Chettiar. The primary objective of APAA is to propagate the exquisite practice of Indian art and culture in their pristine purity and in conformance to tradition.</p>
<p>APAA in its maiden venture has focused on Bharathanatyam, an art that combines artistic expression, vigorous dancing with a sense of spirituality. Students of Bharathanatyam spend years learning the art and perfecting the practice to perform the ‘Arangetram” which is a graduation performance. A student might typically take about 5 to 7 years to perform an Arangetram. If a student were to pursue graduate studies during this time a student should be able to complete post-graduate education. However in pursuit of learning Bharathanatyam, dancers are not awarded degrees or certification for their accomplishment.</p>
<p>APAA in an effort to fulfill this need has developed a structured learning program, using eminent artistes in the field and designed a comprehensive curriculum in performing arts to demonstrate the repertoire of culture that is embedded in these classical arts. The programs have been designed with specific course work and practicals that a student has to successfully complete to get the respective certification. Effective detailed aids have been developed to enhance the learning process with the comprehensive review of the various aspects of the art. From an overview of the various dances in India , to the rudiments of dancing, to clearly depicting the exquisite language of gestures, postures and rhythmical delivery, a student is guided through the various phases of this intricate art with textbooks that concisely explain its relevance and interactive DVDs that vividly describe the precise execution of the art. These valuable learning aids enhance the comprehension and make this a valuable exercise for students to understand the depth and versatility of this art with theory and practicals integrated in a format similar to academic programs.</p>
<p>The teaching aids will initially focus on Bharathanatyam and supplemental aids will be added to other classical dance forms of India such as Mohini Attam, Odissi, Kuchipudi, Kathak and Manipuri. These programs are offered through APAA Authorized Certification Centers (APACs) worldwide to enable students to obtain an undergraduate and post graduate degrees in performing arts. The vision of APAA is to obtain accreditation for this program from renowned Universities in the world, propagate and bring prominence not only to Indian performing arts but also to all other dance and music art forms by offering structured learning programs to students worldwide.</p>-->
	
<?php } ?>
<?php if($title=="demo") { ?>
<div class="apaaContent featuredancerContent">         
 <!-- <h4>Thejaswini Raj</h4>-->
  <img src="<?php echo base_url();?>upload/thejaswini-raj1.png" alt="Smiley face" width="200" height="200" align="left">
  <p style="padding-left:34%;">The institute’s aim is to propagate the enriched art form of Bharatanatyam in New York and New Jersey.</p>
  
  <p style="padding-left:34%;"> As indicated in the Natya Veda, Bharatanatyam is a highly structured and scientific form of dance which involves the physical aspect and the theoretical aspect, which helps to understand minute concepts of the art. The institute provides a medium for such detailed elements of the art to be taught, in order to convey the innate beauty of Bharatanatyam.</p>
   <p style="padding-left:34%;">Shiva Jyoti Dance Academy is also an Alagappa Performing Arts Academy center. The Institute also provides opportunity for learning traditional folk forms as Indian Traditional Folk dances are part and parcel of rich cultural heritage.</p>
  
  <strong style="position: relative;bottom: 26px;">Smt. Thejaswini Raj</strong>
  <br/><br/>
<strong style="font-weight:600;font-size:18px">About the Artistic Director</strong>
<br/><br/>
<p>Smt. Thejaswini Raj is an accomplished professional dance teacher with 30 years of teaching experience. She is well known for her excellent choreographic skills be it an intricate Nritta pattern or an indepth detailed abhinaya piece. She follows the Kaattu Mannar Koyil Muthukumaran Pillai’s (one of the founding teachers of Kalakshetra) style
of Bharatanatyam under the guidance of her father, the late Guru Shri S.V. Srinivasan, who is the direct disciple of Kaattu Mannar Koyil. Smt. Thejeswini continued her training under the tutelage of other renowned gurus of South India in the Pandanallur style. She established Shiva Jyoti Dance Academy in Mumbai in 1980 and since then has trained numerous students in the art; many have been awarded the National Scholarship and have won various dance competitions. Her students have performed at many venues in India, Europe and America.</p>
<p>Since 1991, Smt. Thejaswini has been the Guru to the famous dancer and actress, Meenakshi Shesadri. She has performed all over India and America with Meenakshi during this period. Smt. Thejeswini has also choreographed for established artists such as Sunanda Nair, Anandi Ramachandran and Rajeshwari Sachdev. Her work has received accolades from notable dance critics all over India including Subbudu, Sunil Kothari, Leela Venkataraman and Prakruthi Kashyap. She has conducted performances all over India and abroad including the festivals of dance at Swami Haridas Sammelan, Brindavan, the Madras Music Academy, Narada Gana Shabha, Madras, Kuchipudi Mahahotsav, Mumbai, Ganesh Utasav, Pune, Elephanta Festival, Maharashtra, Chidambaram Natyanjali Festival and all the prestigious banners in Delhi, Calcutta, Chennai, Mumbai, Hyderabad, Bangalore and Bhopal. Her Students in Newyork has performed at venues like the Lincoln center, NY, World 
  </div>
<?php } ?>
</div>
</div>