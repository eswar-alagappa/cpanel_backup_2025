<script type='text/javascript' src="<?php echo base_url()?>assets/home/js/new_jquery.js"></script>

<script type='text/javascript' src="<?php echo base_url()?>assets/home/js/jquery.aviaSlider.min.js"></script>

<script type='text/javascript' src="<?php echo base_url()?>assets/home/js/jquery.prettyPhoto.js"></script>

<script type='text/javascript' src="<?php echo base_url()?>assets/home/js/custom.js"></script>

<div class="danceIndexBanner">

<ul class="aviaslider" id="frontpage-slider">


<li class="slider">

<img src="<?php echo base_url()?>assets/home/images/banner-bg.jpg" name="blankbg"  width="1000" height="340"  id="blankbg">

<img src="<?php echo base_url()?>assets/home/images/slider.jpg" width="448" height="341" />

<h2>APAA Proudly features Ms.Vishal Ramani<br>
The first APAC to launch<br>
APAA Program in San Jose.
<span class="slider1">Director of<br>
Shri Krupa Dance Foundation</span></h2>
</li>

<li class="slider">

<img src="<?php echo base_url()?>assets/home/images/banner-bg.jpg" name="blankbg"  width="1000" height="340"  id="blankbg">

<img src="<?php echo base_url()?>assets/home/images/bannerimg1-1.jpg" width="448" height="341" />

<h2>The hands must explain the meaning.<br/>

The eyes must speak the emotion.<br/>

The feet must beat with a rhythm.<br/>

The body should catch the tune.<span>- Natyasastra</span></h2>

</li>

<li class="slider">

<img src="<?php echo base_url()?>assets/home/images/banner-bg.jpg" name="blankbg"  width="1000" height="340"  id="blankbg">     

<img src="<?php echo base_url()?>assets/home/images/bannerimg2-2.jpg" width="448" height="341" />

<h2>The hands must explain the meaning.<br/>

The eyes must speak the emotion.<br/>

The feet must beat with a rhythm.<br/>

The body should catch the tune.<span>- Natyasastra</span></h2>

 </li>



<li class="slider">

<img src="<?php echo base_url()?>assets/home/images/banner-bg.jpg" name="blankbg"  width="1000" height="340"  id="blankbg">     

<img src="<?php echo base_url()?>assets/home/images/bannerimg3-3.jpg" width="448" height="341" />

<h2>The hands must explain the meaning.<br/>

The eyes must speak the emotion.<br/>

The feet must beat with a rhythm.<br/>

The body should catch the tune.<span>- Natyasastra</span></h2>

 </li>



</ul>

</div>









		<div class="listing">



<div  class="memberLogin">



<h2><a href="<?php echo base_url().'dance/featured-dancer'?>">Featured Dancer</a></h2>









		  



<a href="<?php echo base_url().'dance/featured-dancer'?>"><img width="94" height="77" src="../assets/home/images/dancer-small1.png" class="attachment-homepage wp-post-image" alt="dancer-small" /></a>



<p><strong>Jwala Rejimon</strong>



Jwala Rejimon is a classic dancer. Her Guru is Smt.Mangala Anand.</p>



 


	


</div>







<div class="indexnews">
    <h2><a href="<?php echo base_url().'dance/news'?>">news</a></h2>
               <a href="<?php echo base_url().'dance/news'?>"><img width="94" height="77" src="../assets/home/images/bhoomika-kumar.png" class="attachment-homepage wp-post-image" alt="news" /></a>
    <p><strong>
     Bhoomika Kumar<!--Isha Gondi --><!--Sangeetha Ramachandran    -->  </strong> <!--Disciple of Smt.Jeyanthi Ghatraju - Natyanjali,--><!--Smt.Deepali Vora – Nitya Shetra Dance School,--> 
     <!--completed her Arangetram successfully in Westford, MA.-->Disciple of Smt. Jeyanthi Ghatraju, has successfully completed her Arangetram in Bengaluru on July 23, 2017.</p>
              </div>

<div class="indexcourses">



<h2><a href="javascript:;">ACADEMIC Programs</a></h2>



<ul>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Certificate</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Associate Degree</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Diploma</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Bachelor's Degree</a></li>



</ul>



</div>

</div>



<div class="danceIndexContentOuter">



<div class="danceIndexContent">



<h2>about University</h2>








			<div class="textwidget"><p>Alagappa University is recognized by the University Grants Commission (U.G.C.), Government of India. It has 14 full-fledged departments offering regular Postgraduate, M.Phil. and Ph.D programs.....</p>
</div>
		








<a href="<?php echo base_url().'dance/about-apaa/university'?>"><input name="login" type="button" value="read more" class="readMoreBtn" /></a>



</div>

<div class="danceIndexContent">



<h2>APAA</h2>







<p>This is an example page. It's different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to...



</p>



<a href="<?php echo base_url().'dance/about-apaa'?>"><input name="read more" type="button" value="read more" class="readMoreBtn" /></a>



</div>







<div class="danceIndexContent last">



<h2>Academic Programs</h2>



<ul>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Certificate</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Associate Degree</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Diploma</a></li>



<li><a href="<?php echo base_url().'dance/academics/apaa-programs'?>">Bachelor's Degree</a></li>



</ul>







</div>



</div>



