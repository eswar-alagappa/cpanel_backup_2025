<div class="musicFooter">
<div class="musicFooterLeft"><div class="musicFooterLeftInLeft">© Alagappa Performing Arts Academy.</div>
<div class="musicFooterLeftInRight"> 
  <img src="<?php echo base_url().'music_assets/home/images/facebook-icon.gif' ?>" width="73" height="16" />
  <img src="<?php echo base_url().'music_assets/home/images/twitter-icon.gif' ?>" width="64" height="16" /></div></div>
<div class="musicFooterRight"><a href="http://sanjaytechnologies.org/" target="_blank">Powered by Sanjay Technologies</a></div>
</div>
</div>

</body>
</html>