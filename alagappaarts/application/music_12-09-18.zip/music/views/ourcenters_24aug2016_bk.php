
<div class="musicInnerContent">
 <?php $this->load->view('left_banner'); ?>


 
 
 <div class="musicInnerContentRight">
<div class="musicInnerBanner">Our Centers</div>



			<div class="musicApaaContent">



			<div class="ourCenter">
			  
			<div class="ourCenterContent">
			<div class="ourCenterTitle">TARANAM MUSIC ACADEMY</div>
			<div class="ourCenterInner">
			<p><b>Director Name :</b> Ms.Sangeetha Srikanth<br>
			<b>Address :</b> 1749, Meyerwood Lane South, Flower Mound, Texas- 75028, USA.<br>
			<b>Email :</b> <a>sangeeta_75028@yahoo.com</a><br>
			<b>Phone :</b> 9725395934″</p>
			</div>
			</div>
			  </div>

			 
			<div class="ourCenter">
			  
			<div class="ourCenterContent">
			<div class="ourCenterTitle">Nrityananda School of Bharatanatyam &amp; Music</div>
			<div class="ourCenterInner">
			<p><b>Director Name :</b> Ms.Sangeetha Agarwal / Ms.Vibha Harikar<br>
			<b>ADDRESS:</b> 4921, Sammy Joe Drive, Fairfax, VA 22030-8274. USA<br>
			<b>E-mail Id :</b> <a href="mailto:vibha.harikar@nrityananda.com">vibha.harikar@nrityananda.com </a><br>
			<b>Number</b> 7036464436″</p>
			</div>
			</div>
			  </div>

			 
			<div class="ourCenter">
			  
			<div class="ourCenterContent">
			<div class="ourCenterTitle">Sangeetha Swara Laya(SSL), Malaysia</div>
			<div class="ourCenterInner">
			<ul><strong>Branch Locations at Malaysia:</strong>
			<li>Selangar</li>
			<li>Shah Alam</li>
			<li>Penang  </li>
			<li>Kedah</li>
			<li>Johar</li>
			<li>Perak</li>
			</ul>
			</div>
			</div>
			  </div>
			  </div> 

						

			</div>



</div>