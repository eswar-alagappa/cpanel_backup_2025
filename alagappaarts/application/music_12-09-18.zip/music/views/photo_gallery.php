<link type="text/css" href="<?php echo base_url()?>assets/home/css/ui.all.css" rel="stylesheet" />

<script src="//code.jquery.com/jquery-1.10.2.js"></script>  
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#accordion").accordion({active: false, collapsible: true, alwaysOpen: false, autoheight: false});
});
</script>
<style>
.ui-accordion .ui-accordion-content{
	border-style:none;
}
</style>
<div class="musicInnerContent">
 <?php $this->load->view('left_banner'); ?>


 
 
 <div class="musicInnerContentRight">
<div class="musicInnerBanner">
<h2><span>Photo gallery</span></h2>
</div>

<div class="musicApaaContent">
 		 
<div class="gallery galleryid-118 gallery-columns-3 gallery-size-thumbnail" id="gallery-1"><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/veena1.jpg"><img width="150" height="150" aria-describedby="gallery-1-445" alt="Veena" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/veena1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-445" class="wp-caption-text gallery-caption">
				Veena
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/tablas1.jpg"><img width="150" height="150" aria-describedby="gallery-1-444" alt="Tablas" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/tablas1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-444" class="wp-caption-text gallery-caption">
				Tablas
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/sarod1.jpg"><img width="150" height="150" aria-describedby="gallery-1-443" alt="Sarod" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/sarod1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-443" class="wp-caption-text gallery-caption">
				Sarod
				</dd></dl><br style="clear: both"><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/harmonium1.jpg"><img width="150" height="150" aria-describedby="gallery-1-442" alt="Harmonium" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/harmonium1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-442" class="wp-caption-text gallery-caption">
				Harmonium
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/tambura2.jpg"><img width="150" height="150" aria-describedby="gallery-1-441" alt="Tambura" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/tambura2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-441" class="wp-caption-text gallery-caption">
				Tambura
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/bansuri-11.jpg"><img width="150" height="150" aria-describedby="gallery-1-440" alt="Bansuri" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/bansuri-11-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-440" class="wp-caption-text gallery-caption">
				Bansuri
				</dd></dl><br style="clear: both">
		</div>

	  </div>
	  
	  
</div>



</div>