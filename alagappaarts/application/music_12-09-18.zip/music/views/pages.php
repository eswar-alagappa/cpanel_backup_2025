<div class="musicInnerContentOuter">
	<div class="musicInnerContent">

		<?php $this->load->view('left_banner'); ?>
	 
		<div class="musicInnerContentRight">
		<div class="musicInnerBanner">
			<?php echo $title; ?>
		</div>

		<?php   print_r($page); ?>	
		</div>
	</div>
</div>