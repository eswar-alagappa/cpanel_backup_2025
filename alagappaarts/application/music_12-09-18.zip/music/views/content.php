
<div class="homeMusicBanner"><img src="<?php echo base_url().'music_assets/home/images/Music-banner.jpg' ?>" width="1000" height="265" /></div>



	<div class="musicIndexContentOuter">

<div class="musicIndexContent">

<div class="welcomeContent equalheight">

<h3>WELCOME TO<br />

<span>ALAGAPPA ARTS ACADEMY</span></h3>

<p>Students of Indian classical performing arts spend years learning the art form and perfecting the art through rigorous practice to perform the 'Arangetram' or the formal initiation of the student to perform on stage. </p>

<p>This preparation of the student can take five to seven years and if the same student were to pursue academic studies during that time, he or she would be able to complete post graduate collegiate education...</p>

<a href="<?php echo base_url().'music/apaa'?>"><img src="<?php echo base_url().'music_assets/home/images/readmore-btn.png' ?>" width="93" height="30"/></a>

</div>

<div class="academicContent equalheight">

<h3>Academic <span>features</span></h3>

<ul>

<li><a href="<?php echo base_url().'music/academics/apaa-programs/1'?>">Certificate in Vocal and Instrumental Music</a></li>

<li><a href="<?php echo base_url().'music/academics/apaa-programs/1'?>">Diploma in Vocal and Instrumental Music</a></li>

<li><a href="<?php echo base_url().'music/academics/apaa-programs/1'?>">Bachelor's Degree Vocal and Instrumental Music</a></li>

</ul>

</div>

<div class="videoGallery">

<h3>video <span>gallery</span></h3>

<a href="<?php echo base_url().'music/academics/video-gallery'?>"><img src="<?php echo base_url().'music_assets/home/images/video-img.gif' ?>" width="190" height="145" /></a></div>

</div>

</div>