</div>
<div class="footerOuter">
  <div class="footer">
    <div class="footerLeft">© Alagappa Performing Arts Academy. </div>
    <div class="footerRight"><a href="http://sanjaytechnologies.org/" target="_blank">Powered by Sanjay Technologies</a></div>
  </div>
</div>
</body>
</html>