<div class="content">

   

    <div class="contentOuter">

    <div class="dashboardContent">

    

      <div class="dashboardDetails">

      <div class="dashboardDetailsTitle"><img src="http://alagappaarts.com/userpanel/web/images/schedule-icon.gif" width="20" height="21" />Exam schedule</div>

      <div class="dashboardDetailsInner">

      

      
      <span>Certificate</span>

      <table width="100%" border="0" cellspacing="0" cellpadding="0">

  <tr>

    <th width="22%" align="left" valign="top" scope="col">Course Code</th>

    <th width="34%" align="left" valign="top" scope="col">Exam From</th>

    <th width="44%" align="left" valign="top" scope="col">Till</th>

  </tr>

  

  

  

  

				  <tr class=''>

                <td><a href='online_exam_instruction.php?courseid=1'>CEB 01</a></td>

                <td> 24-Dec-2015  </td>

                <td>31-Dec-2015 </td></tr>
  

</table>

<span class="moreBtn"><a href="student_exam_schedule.php">MOre</a></span>


      </div>

        

      </div>

      <div class="dashboardDetails ">

      <div class="dashboardDetailsTitle"><img src="http://alagappaarts.com/userpanel/web/images/payment-icon.gif" width="20" height="21" />Payments</div>

      <div class="dashboardDetailsInner">

           
	<span>Payment History </span> 

      <table width="100%" border="0" cellspacing="0" cellpadding="0">

  <tr>

    <th width="33%" align="left" valign="top" scope="col">Paid on</th>

    <th width="34%" align="left" valign="top" scope="col">Amount($)</th>

      <th width="34%" align="left" valign="top" scope="col">Mode</th>

    <th width="33%" align="left" valign="top" scope="col">Status </th>

  </tr>

  <tr class='altRows'><td>04-Dec-2015</td>

    <td>200</td>

	 <td>Check Payment</td>

    <td>Done</td>

  </tr>
  

</table>



<span class="moreBtn"><a href="student_payments.php">MOre</a></span>


      </div>

      

        

      </div>

      

      
    </div>

      <div>

        

      </div>

           

    </div>

  </div>