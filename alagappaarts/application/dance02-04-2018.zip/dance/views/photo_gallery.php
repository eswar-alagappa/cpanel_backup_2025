<link type="text/css" href="<?php echo base_url()?>assets/home/css/ui.all.css" rel="stylesheet" />

<script src="//code.jquery.com/jquery-1.10.2.js"></script>  
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#accordion").accordion({active: false, collapsible: true, alwaysOpen: false, autoheight: false});
});
</script>
<style>
.ui-accordion .ui-accordion-content{
	border-style:none;
}
</style>
<div class="danceInnerContent">
 <?php $this->load->view('left_banner'); ?>


 
 
 <div class="danceInnerContentRight">
<div class="danceBanner">
<h2><span>Photo gallery</span></h2>
</div>

    
<div class="apaaContent">

	
	<!-- Gallery Start -->
	<div class="gallery galleryid-2318 gallery-columns-3 gallery-size-thumbnail" id="gallery-1"><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/01-kavya-preview2.jpg"><img width="150" height="150" aria-describedby="gallery-1-2598" alt="Kavyalakshmi  Muralidharan Nrithyakshethra Dance Academy" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/01-kavya-preview2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2598" class="wp-caption-text gallery-caption">
				Kavyalakshmi  <br>Muralidharan <br>Nrithyakshethra <br>Dance Academy 
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/1-preview2.jpg"><img width="150" height="150" aria-describedby="gallery-1-2610" alt="Anjali" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/1-preview2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2610" class="wp-caption-text gallery-caption">
				Anjali
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/2-preview1.jpg"><img width="150" height="150" aria-describedby="gallery-1-2607" alt="Kapotham" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/2-preview1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2607" class="wp-caption-text gallery-caption">
				Kapotham
				</dd></dl><br style="clear: both"><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/24-preview2.jpg"><img width="150" height="150" aria-describedby="gallery-1-2606" alt="Avahitham" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/24-preview2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2606" class="wp-caption-text gallery-caption">
				Avahitham
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/6-preview2.jpg"><img width="150" height="150" aria-describedby="gallery-1-2603" alt="Pushpaputam" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/6-preview2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2603" class="wp-caption-text gallery-caption">
				Pushpaputam
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/jaina-julia-shruti_0-preview2.jpg"><img width="150" height="150" aria-describedby="gallery-1-2602" alt="Jaina, Julia, Shruti" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/jaina-julia-shruti_0-preview2-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2602" class="wp-caption-text gallery-caption">
				Jaina, Julia, Shruti
				</dd></dl><br style="clear: both"><dl class="gallery-item">
			<dt class="gallery-icon portrait">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/portfolio080_0-preview1.jpg"><img width="150" height="150" aria-describedby="gallery-1-2599" alt="Guru Vishal Ramani, Shri Krupa  Dance Foundation" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/portfolio080_0-preview1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2599" class="wp-caption-text gallery-caption">
				Guru Vishal Ramani, <br>Shri Krupa <br> Dance Foundation
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/tishani-preview1.jpg"><img width="150" height="150" aria-describedby="gallery-1-2611" alt="Nithyashetra Dance Academy" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/tishani-preview1-150x150.jpg"></a>
			</dt>
				<dd id="gallery-1-2611" class="wp-caption-text gallery-caption">
				Nithyashetra<br> Dance <br>Academy
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/sivagami-preview2.png"><img width="150" height="150" aria-describedby="gallery-1-2614" alt="Sivagami" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/sivagami-preview2-150x150.png"></a>
			</dt>
				<dd id="gallery-1-2614" class="wp-caption-text gallery-caption">
				Sivagami
				</dd></dl><br style="clear: both"><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/isha gondi.jpeg"><img width="150" height="150" aria-describedby="gallery-1-2615" alt="Isha Gondi" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/isha gondi150.jpeg"></a>
			</dt>
				<dd id="gallery-1-2615" class="wp-caption-text gallery-caption">
				Isha Gondi
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/Sahana Dinakaran.jpeg"><img width="150" height="150" aria-describedby="gallery-1-2616" alt="Sahana Dinakaran" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/Sahana Dinakaran150.jpg"></a>
			</dt>
				<dd id="gallery-1-2616" class="wp-caption-text gallery-caption">
				Sahana Dinakaran
				</dd></dl><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/Tishani vora.jpeg"><img width="150" height="150" aria-describedby="gallery-1-2617" alt="Tishani vora" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/Tishani vora150.jpeg"></a>
			</dt>
				<dd id="gallery-1-2617" class="wp-caption-text gallery-caption">
				Tishani vora
				</dd></dl><br style="clear: both"><dl class="gallery-item">
			<dt class="gallery-icon landscape">
				<a data-rel="lightbox-gallery-1" href="<?php echo base_url() ?>upload/Yamini.jpeg"><img width="150" height="150" aria-describedby="gallery-1-2618" alt="Yamini" class="attachment-thumbnail" src="<?php echo base_url() ?>upload/Yamini150.jpeg"></a>
			</dt>
				<dd id="gallery-1-2618" class="wp-caption-text gallery-caption">
				Yamini
				</dd></dl>
		</div>
	
	<!-- Gallery End -->
	
	
</div>
</div>



</div>