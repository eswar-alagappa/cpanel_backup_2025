/*
 * HTML5 support for IE 8 and older browsers
 */

document.createElement('header'); 
document.createElement('nav'); 
document.createElement('article'); 
document.createElement('footer');