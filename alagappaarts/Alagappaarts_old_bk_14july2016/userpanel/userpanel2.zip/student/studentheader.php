<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript charset=utf-8">
<title>alagappaarts-Online exam</title>
<link href="../web/css/style-student.css" type="text/css" rel="stylesheet"  />
<link rel="stylesheet" href="../web/css/colorbox.css" type="text/css" media="screen" />
<script type="text/javascript" src="../web/scripts/jquery.min.js"></script>
  <script type="text/javascript" src="../web/scripts/jquery.plugin.js"></script>
 <script type="text/javascript" src="../web/scripts/jquery.countdown.js"></script>
<script type="text/javascript" src="../web/scripts/jquery.validate.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.min.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.pack.js"></script>
<script src="../web/scripts/questions.js" type="text/javascript"></script>
 <script type="text/javascript" src="../web/ckeditor/ckeditor.js"></script>
<link href="../web/css/jquery.datepick.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div class=" wrapper">
  <div class="header">
    <div class="headerTop">
      <div class="logo"><a href="#"><img src="../web/images/spacer.gif" width="1" height="1" class="logoImg" /></a></div>
       <div class="menu">
        <ul id="nav">
        
        <li  class="top"><a href="student_student_view.php">Program Enrolled</a></li>
          <li><a class="top_link" href="javascript:;">Exams</a>
          	<ul class="sub">
            
<li><a href="student_exam_schedule.php">Schedule</a></li>
<li><a href="sample_exam_instruction.php">Sample Exam</a></li>
<li><a href="online_exam_instruction.php">Online Exams</a></li>
<li><a href="student_exam_result.php">Exam Results</a></li>
</ul>
          </li>
            <li><a href="student_payments.php">Payments</a></li>
            <li><a  href="student_feedback_listing.php">Feedback </a></li>
            <li  ><a href="../downloads/exam-guidelines.pdf" target="_blank">Program Guidelines </a></li>
            <li class="last"><a href="../downloads/APAA_On_Line_Exam_Instructions.pdf" target="_blank">Exam Instructions </a></li>
           </ul>
      </div>
    </div>
    
  </div>