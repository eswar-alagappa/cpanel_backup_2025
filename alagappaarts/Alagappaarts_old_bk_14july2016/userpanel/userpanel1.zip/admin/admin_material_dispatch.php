<?php
include("../config/config.inc.php");
include("../config/classes/loginmaster.class.php");
$roleid = $_SESSION[userinfo][role_id];
$userid = $_SESSION[userinfo][user_id];
$arrlogin = array('role_id'=> $roleid ,'user_id'=>$userid);
$loginmaster = new loginmaster();
$admin  = $loginmaster->isadmin($arrlogin);
if(!$admin)
{
	header('location:index.php?msg=Enter username password');
}
else{
include('adminheader.php');
?>
<div class="content">
    <div class="topNav">
      <ul>
        <li><a  href="masters_dashboard.html">dashboard</a></li>
      
        <li><a  href="javascript:;">Materials</a></li>
        <li class="last"> &nbsp;  Dispatch Material</li>
      </ul>
    </div>
    
    <div class="studentViewContent">
    <h2><span>Dispatch Material </span></h2>
     </div>
  </div>
<?php 
include('adminfooter.php');
}
?>

