<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>alagappaarts</title>
<link href="../web/css/style.css" type="text/css" rel="stylesheet"  />
<link href="../web/css/jquery.datepick.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../web/scripts/jquery.min.js"></script>
<script type="text/javascript" src="../web/scripts/jquery.validate.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.min.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.pack.js"></script>
 <script type="text/javascript" src="../web/ckeditor/ckeditor.js"></script>
</head>
<body>
<div class=" wrapper">
  <div class="header">
    <div class="headerTop">
      <div class="logo"><a href="#"><img src="../web/images/spacer.gif" width="1" height="1" class="logoImg" /></a></div>
      <div class="menu">
  <ul id="nav">
    <li class="top"><a class="top_link" href="javascript:;">Masters </a>
      <ul class="sub">
       <li><a href="admin_program_listing.php">Programs </a></li> <li><a href="admin_course_listing.php">Courses</a></li>
<li><a href="admin_programfee_listing.php">Fee</a></li>
<li><a href="admin_admin_listing.php">Admin</a></li>
<!--<li><a href="admin_material_type_listing.php">material types</a></li>
<li><a href="admin_material_listing.php">materials</a></li>-->
      </ul>
    </li>
    <!--<li><a class="top_link" href="javascript:;">Materials </a>
      <ul class="sub">
        <li><a href="admin_material_stock.php">Stock Material</a></li>
        <li><a href="admin_material_dispatch.php">Dispatch Material</a></li>
      </ul>
    </li>-->
    <li><a class="top_link" href="admin_centre_listing.php">Centers </a>
      <ul class="sub">
        
      </ul>
    </li>
     <li><a href="admin_student_listing.php">Students </a></li>
     
    <li><a class="top_link" href="javascript:;">Online Exam </a>
      <ul class="sub">
        <li><a href="admin_questiontype_listing.php">Question Types </a></li>
        <li><a href="admin_question_listing.php">Questions</a></li>
         
          <li><a href="admin_exam_list.php">Reassign Exam</a></li>
      </ul>
    </li>
      <li><a class="top_link" href="javascript:;">Payments</a>
       <ul class="sub">
        <li><a href="admin_payment_paypal.php">Paypal </a></li>
        <li><a href="admin_payment_check.php">Pending Payment</a></li>
         
         
      </ul>
      
      </li>
    <li><a  href="admin_announcements_listing.php">Messages</a></li>
     <li><a href="admin_feedback_listing.php">Feedback </a></li>
     <li class="last"><a class="top_link" href="admin_student_wise_report.php">Reports</a>  </li>
    
   
  </ul>
</div>
    </div>
    <div class="headerBottom">
      <div class="admiTitle">Welcome Administrator</div>
      <div class="menuBottom">
        <ul>
          <li class="homeIcon"><a href="http://alagappaarts.com/">website Home</a></li>
                      <li class="dashboardIcon"><a href="dashboard.php"> dashboard</a></li>
                      <!--<li class="loginviewnav"><a href="admin_log_view.php">Log View</a></li>-->
                      <li class="profilenav"><a href="admin_view-profile.php">Profile</a></li>
                   <li class="loginviewnav"><a  href="../downloads/Program_Guide.pdf" target="_blank">Program Guidelines </a>   </li>
           <li class="logoutIcon "><a class="end" href="logout.php">LOg out</a></li>
        </ul>
      </div>
    </div>
  </div>