<?PHP

#Database settings;
/* id : check list item -5 
   Change  the database name, Username/Password for  the db 

*/
/*define( "DB_HOSTNAME", "localhost" );
define( "DB_USERNAME", "appaarts_alagapa" );
define( "DB_PASSWORD", "Vb2=w!,1]TJ;" );
define( "DB_DATABASE", "appaarts_alagappa" );

define( "DB_HOSTNAME", "localhost" );
define( "DB_USERNAME", "appaarts_alagapa" );
define( "DB_PASSWORD", "nn8}Uf%Q8gka" );
define( "DB_DATABASE", "appaarts_alagappalive" );*/

define( "DB_HOSTNAME", "localhost" );
define( "DB_USERNAME", "appaarts_apaanew" );
define( "DB_PASSWORD", "D-exCvrQrdz!" );
define( "DB_DATABASE", "appaarts_apaanew" );


?>