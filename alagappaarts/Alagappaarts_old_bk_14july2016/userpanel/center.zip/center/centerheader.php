<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Script-Type" content="text/javascript charset=utf-8">
<title>alagappaarts</title>
<link href="../web/css/style-student.css" type="text/css" rel="stylesheet"  />
<link href="../web/css/style-center.css" type="text/css" rel="stylesheet"  />
<link rel="stylesheet" href="../web/css/colorbox.css" type="text/css" media="screen" />
<script type="text/javascript" src="../web/scripts/jquery.min.js"></script>
<script type="text/javascript" src="../web/scripts/jquery.validate.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.min.js"></script>
<script type="text/javascript" src="../web/scripts/datetimepicker/jquery.datepick.pack.js"></script>
<script src="../web/scripts/questions.js" type="text/javascript"></script>
 <script type="text/javascript" src="../web/ckeditor/ckeditor.js"></script>
 <script type="text/javascript" src="../web/scripts/jquery.countdown.js"></script>
<link href="../web/css/jquery.datepick.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div class=" wrapper">
  <div class="header">
    <div class="headerTop">
      <div class="logo"><a href="#"><img src="../web/images/spacer.gif" width="1" height="1" class="logoImg" /></a></div>
       <div class="menu">
        <ul id="nav">
    
          	    <li class="top"><a class="top_link" href="center_student_listing.php">Students</a></li>
                 <li><a href="center_exam_schedule.php">Exams</a></li>
   	       <li><a href="center_student_payments.php">Payments</a></li>
            <li><a  href="center_exam_result.php">Result </a></li>
            <li class="last"><a  href="../downloads/Program_Guide_0412.pdf" target="_blank">Program Guidelines </a></li>
                        
         
            
            
            
           </ul>
      </div>
    </div>
    
  </div>