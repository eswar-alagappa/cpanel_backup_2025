<?php 
include("../config/config.inc.php"); 
include("../config/classes/loginmaster.class.php");
$roleid = $_SESSION['studentinfo'][role_id];
$userid = $_SESSION['studentinfo'][user_id];
$username = $_SESSION['studentinfo'][first_name];
$arrlogin = array('role_id'=> $roleid ,'user_id'=>$userid);
$loginmaster = new loginmaster();
$student  = $loginmaster->isstudent($arrlogin);

?>
<?php 
if(!$student)
{
	header('location:index.php?msg=Enter username password');
}
else{
include("../config/classes/onlineexam.class.php");
$onlineexam = new onlineexam();	
$jsonquestarray=$_REQUEST['hdnfrmArray'];
$stringObject = json_decode(stripslashes($jsonquestarray));
$arrayfin=json_decode(json_encode($stringObject), true);
$totalQuestion = count($arrayfin);
$j=0;$k=0;$m=0;$l=1;

foreach ($arrayfin  as $matchthefollowing){
if($matchthefollowing['questiontype'] == 'match-the-following') 
{
	$arrquestion=$onlineexam->getQuestion($matchthefollowing[questionid],$matchthefollowing[position]);		    $matchthefollowingquestions[$j]=$arrquestion;
	$j++;
}
}
foreach($matchthefollowingquestions as $matchthefollowinganswer)
{
	$answer=str_replace("'","",$matchthefollowinganswer[0][answer]);
$matchthefollowing_answer[$k][answer]=trim($answer);
$matchthefollowing_answer[$k]['answerno']=$l;	
$matchthefollowing_answer[$k][correctquestionid] = trim($matchthefollowinganswer[0][questionid]);
$k++;$l++;
}
shuffle($matchthefollowing_answer);
foreach($matchthefollowingquestions as $matchthefollowingquestion)
{
$matchthefollowing_answer[$m][question]=trim($matchthefollowingquestion[0][question]);
$matchthefollowing_answer[$m][questionid]=trim($matchthefollowingquestion[0][questionid]);
$m++;
}


?>
<script type="text/javascript">
var  jsonstring= '<?php echo json_encode($stringObject) ?>';
var arrfinobj = JSON.parse(jsonstring);
</script>

<form method="get">
 <input type='hidden' id='hdnarrayindex' name="hdnarrayindex" value='<?php echo $_SESSION['questCount'];?>'/>
  </form>
  
<?php
$i=$_SESSION['questCount'];
$arrayIndex=$i+1;
	
if($_SESSION['userexaminfo'])
{
if($_SESSION['userexaminfo']['currenttiming']=='' || $_SESSION['userexaminfo']['currenttiming']==0)
	{
		$updatetime = "update assign_exam set currenttiming ='".$_SESSION['userexaminfo']['examduration']."'  where id = '".$_SESSION['userexaminfo'][assignedid]."'";
		$_SESSION['userexaminfo']['currenttiming']=$_SESSION['userexaminfo']['examduration'];
		$execbeginexam = $DB -> Execute($updatetime);
	}
}
include("../config/classes/keywordmaster.class.php");
include('studentheader.php');
$studentEmail = $onlineexam->getstudentemail($_SESSION[studentinfo][user_id]);
//echo $i;
?>
<script type="text/javascript" >

$('.btnrdoselected').live('click',function(e){
	e.preventDefault();
	$(".btnrdoselected").unbind("click");
	var rdlName=$(this).attr('alt');
	var periods = $('#timer').countdown('getTimes');
	var arrayindex=parseInt($('#hdnarrayindex').val());
	var currentseconds = $.countdown.periodsToSeconds(periods);
	if ($("input:radio[@name='"+rdlName+"']:checked").val())
	 {
		var answer = $("input:radio[@name='"+rdlName+"']:checked").val();
		
		changequestion(answer,'NEXT',currentseconds,arrfinobj[arrayindex]["questionid"]); 
		return false;
	}
});

$('.fillAnswer').live('click',function(e)
{
e.preventDefault();
	$(".fillAnswer").unbind("click");
	var questAnswer=$(this).attr('alt');
	var periods = $('#timer').countdown('getTimes');
	var currentseconds = $.countdown.periodsToSeconds(periods);
	var fillanswer = $("input:text[@name='questAnswer']").val();
	 var characterReg = /^[a-zA-Z0-9() ,]+$/;
	 var arrayindex=parseInt($('#hdnarrayindex').val());
	if(fillanswer &&   characterReg.test(fillanswer))
	{
		changequestion($.trim(fillanswer),'NEXT',currentseconds,arrfinobj[arrayindex]["questionid"]);
		return false;
	}
	else {  $('.error').remove();$('.part2Content').append("<div class='error fillerror'> Please Enter only  alphabets and numbers  </div>");}
});

$('.subjectiveanswer').live('click',function(e)
{
e.preventDefault();
	$(".subjectiveanswer").unbind("click");
	var txtAnswer=$(this).attr('alt');
	var periods = $('#timer').countdown('getTimes');
	var currentseconds = $.countdown.periodsToSeconds(periods);
	var subjectiveanswer = CKEDITOR.instances['txtAnswer'].getData();
	var arrayindex=parseInt($('#hdnarrayindex').val());
	changequestion($.trim(subjectiveanswer),'NEXT',currentseconds,arrfinobj[arrayindex]["questionid"]);
	return false;
});

function disableF5(e) { if ((e.which || e.keyCode) == 116) e.preventDefault(); };
$(document).bind("keydown", disableF5);
function changequestion(answer,option,seconds,currentquestion)
		{
			var last=0;
			var complete=0;
			$(".onlineExamsBottom").html('<div class="ajax-loader"><img src="../web/images/ajax-loader.gif" /></div>');
		var arrayindex=parseInt($('#hdnarrayindex').val());
		var	complete='';
		var	position='';
		var	nexttype='';
		var	arrayquestion='';
		if(arrayindex+1 < '<?php echo $totalQuestion; ?>')
		{
			var position=arrfinobj[arrayindex+1]["position"];
			var nexttype=arrfinobj[arrayindex+1]["questiontype"];
			if(arrayindex==-1 || currentquestion=='fq')
			{
				currenttype=''
			}
			else
			{
				currenttype=arrfinobj[arrayindex]["questiontype"];
			}
			if(arrfinobj[arrayindex+1]['questiontype']=='match-the-following')
			{
				arrayquestion='<?php echo json_encode($matchthefollowing_answer);?>';
			}
			else 
			{ 
		  	   arrayquestion = arrfinobj[arrayindex+1]["questionid"];
			}
			if(arrayindex+2 =='<?php echo $totalQuestion; ?>')
			{
				last=1;
			}
			
		}
		else {
			complete=1;
			}
		if(!seconds)
		{
			seconds = 0;
		}

		$.ajax({
		type: "POST",
		url: "temp-question.php",
		data:{selected:answer,option:option,seconds:seconds,currentquestion:currentquestion,currenttype:currenttype,nextquestion:arrayquestion,position:position,nexttype:nexttype,last:last,complete:complete,StudentID:$('#hdnStudentID').val(),CourseID:$('#hdnCourseID').val()},
		success: function(result)
					 {
						$(".dynamicInfo").html(result);
						var arrayindexval=parseInt($('#hdnarrayindex').val());
						
						if(arrayindex+1 < '<?php echo $totalQuestion; ?>')
					{
						if(arrfinobj[arrayindex+1]["questiontype"]=='match-the-following')
						{
							arrayindexval+=10;
						}
						else{
							arrayindexval+=1;
							}
					}
						
						$('#hdnarrayindex').val(arrayindexval);
						return false;
					 },
					error: function(xhr, statusText, errorThrown){alert('Sorry for inconvenience');
						window.location.href='dashboard.php';}
					
				 });
		
		
		}
		


	
function matchthefollowing(txtCorrectanswer)
{
	var periods = $('#timer').countdown('getTimes');
	var flag = false ;
	var currentseconds = $.countdown.periodsToSeconds(periods);
	var countmatch =1;
	var matchquest='';

	
	$('.dynamicfields input.matchAnswer').each(function() {
		if( $(this).val() == '' || isNaN($(this).val()))
		flag = true ;
		return false;
	});
	if(!flag)
	{
	$('.dynamicfields input.matchAnswer').each(function() {
	 $(".onlineExamsBottom").html('<div class="ajax-loader"><img src="../web/images/ajax-loader.gif" /></div>');
			if(countmatch==1){
				matchquest=($(this).val()+'#@'+$(this).prev().val()+'#@'+$(this).attr('id')+'#@'+$(this).prev().attr('id')+'#@'+$(this).next().val());
				
			}
			else
			 {
				matchquest+='!~@'+($(this).val()+'#@'+$(this).prev().val()+'#@'+$(this).attr('id')+'#@'+$(this).prev().attr('id')+'#@'+$(this).next().val());
			 }
			countmatch++;

    });
	var arrayindex=parseInt($('#hdnarrayindex').val());

		$.ajax({
					 type: "POST",
					 url: "temp-question.php",
					 data:{matchquest:matchquest,option:'NEXT',seconds:currentseconds,currentquestion:arrfinobj[arrayindex]["questionid"],currenttype:arrfinobj[arrayindex]["questiontype"],nextquestion:arrfinobj[arrayindex+1]["questionid"],position:arrfinobj[arrayindex+1]["position"],nexttype:arrfinobj[arrayindex+1]["questiontype"],StudentID:$('#hdnStudentID').val(),CourseID:$('#hdnCourseID').val()},
					 success: function(result)
					 {
						 var arrayindexval=parseInt($('#hdnarrayindex').val())+1;
					     $(".dynamicInfo").html(result);
						
						 $('#hdnarrayindex').val(arrayindexval);
						 return false;
					 },
					 error: function(xhr, statusText, errorThrown){
						alert('Sorry for inconvenience');
						window.location.href='dashboard.php';
						//window.location.href=window.location.href;
						//alert(xhr.status);
						
						
						}
				 });

	}	 else { $('.error').remove();$('#match').append("<div class='error'> Please enter all the filed with valid number</div>");}
}


$(document).ready(function() {
$(document).keydown(function(e) {
var element = e.target.nodeName.toLowerCase();
if (e.keyCode === 8) {
		if (element != 'input' && element != 'textarea') {
        return false;
    }
}else if (e.keyCode === 13) {
	 return false;
} else if (e.keyCode === 116) {
	 return false;
}
});
 $(document).bind("contextmenu",function(e){
              return false;
       });
	$('input[name$="questAnswer"]').live ('click',function(){
			if($('input[name$="questAnswer"]:checked').length != 0 ){
			$('.nextd').hide();
			$('.next').show();
			}
	})
	$('input[name$="questAnswer"]').live ('keyup',function( ){
			if($.trim($(this).val())){
				$('.nextd').hide();
			$('.next').show();
		}
	})
	$('.matchAnswer').live ('keyup',function(){
		var flag = 0;
		$('.matchAnswer').each(function(){
			if(!$.trim($(this).val())){
			flag = 1;
				}
			})
		//	alert(flag);
			if(flag == 0){
				$('.nextd').hide();
			$('.next').show();
			}
		})
			
	$("#btnStartTest").click(function(){
		changequestion(null);
		});
		
		
$('#logOut').click(function(){
		var periods = $('#timer').countdown('getTimes');
	var currentseconds = $.countdown.periodsToSeconds(periods);
window.location.href="logout.php?currentseconds="+currentseconds;
});
	
});
</script>
<script type='text/javascript'>
function getckeditor()
{
	if (CKEDITOR.instances['txtAnswer']) {
	delete CKEDITOR.instances['txtAnswer'];
	}	
CKEDITOR.replace( 'txtAnswer',
{
height: '200',
resize_enabled : 'false',
resize_maxHeight : '200',
resize_maxWidth : '450',
resize_minHeight: '200',
resize_minWidth: '450',
toolbar :
[
[ 'Styles','Format' ],
['Bold', 'Italic', '-', 'NumberedList', 'BulletedList', '-', 'Link', ]
],
width:'800',
removePlugins : 'contextmenu' 
}
);


}
</script>
<div class="headerBottom">

      <div class="admiTitle">Welcome  <?php  echo $_SESSION[studentinfo][first_name]; ?></div>
      <div class="menuBottom">
       <ul>
          <li class="homeIcon"><a href="http://alagappaarts.com">website Home</a></li>
            <li class="dashboardIconinacive"><a href="dashboard.php">dashboard</a></li>
          <li class="profilenav"><a href="student_profile_students.php">Profile</a></li> 
          <li class="logoutIcon "><a class="end" id="logOut" href="javascript:;">Log out</a></li>
        </ul>
      </div>
    </div>
  <?php
  echo "<noscript>
<div class='content'>
<div class='contentOuter'>
<div style='height: 300px' >
<br/><p style='color: red;font-size: 20px;font-weight: normal;'><b>Please enable Javascript in your browser to take up the exam</b></p>
<br/><br/>
</div>
</div>
</div>
</noscript>
";
  ?>
 
  <?php 
  if(isset($_SESSION['userexaminfo']))
  {
	  $courseid = $_SESSION['userexaminfo']['course_id'];
	  $coursecode = $onlineexam->getcoursecodebyid( $courseid);
  }
		$examdetails = $_SESSION['userexaminfo'];
		$diffseconds = $examdetails['examduration'] - $examdetails['currenttiming'];
		$remainingsecond = $examdetails['examduration'] - $diffseconds;
		echo " <div class='content'>
    <div class='topNav'>
      <ul>
      <li><a  href='dashboard.php'>dashboard</a></li>
        <li class='last'> &nbsp; Online Exams</li>
             
      </ul>
    </div>
    <div class='contentOuter'>
    <h2 id='appendTimer'>Online Exams - {$coursecode}</h2>
	
      <div class='contentInner'>";
	  $questiontypecount = count($examdetails['questiontypeid']);
	echo "
	<div class='navi'>
	<ul>";
	$j=0;
	foreach($examdetails[questiontypeid] as $questionpart)
	{ 
		if($j<$questiontypecount)
		{
		$classname = "disableBtn";
		$part = $j+1;
		echo "<li id='".$questionpart."' class='{$classname}'><a href='javascript:;'><span>Part {$part}</span></a></li>";
		$j++;
		}
	}
	echo "</ul> </div>";	  
	  ?>
	<script type='text/javascript'>$(document).ready(function() 
	{
changequestion(0,'CONTINUE','<?php echo $remainingsecond;?>','fq'); 
	});
         
    </script>
       <div class='dynamicInfo'>
  <div class='ajax-loader'><img src='../web/images/ajax-loader.gif' /></div>

      </div>
      </div>
    </div>
    </div>
    <input type='hidden' id='hdnStudentID' value='<?php echo $_SESSION['userexaminfo']['student_id'];?>'/>
 <input type='hidden' id='hdnCourseID' value='<?php echo $_SESSION['userexaminfo']['course_id'];?>'/> 
<?php 

$updatetime = "update assign_exam set currenttiming ='".$_REQUEST[currentseconds]."'  where id = '".$_SESSION['userexaminfo'][assignedid]."'";
$execbeginexam = $DB -> Execute($updatetime);
include('studentfooter.php');
}
?>