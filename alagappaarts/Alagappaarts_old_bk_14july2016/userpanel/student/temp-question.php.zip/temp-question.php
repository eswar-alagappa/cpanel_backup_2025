<?php
include("../config/config.inc.php");
/*include("../config/classes/loginmaster.class.php");*/
include("../config/classes/onlineexam.class.php");

$roleid = $_SESSION[studentinfo]['role_id'];
$userid = $_SESSION[studentinfo]['user_id'];
$username = $_SESSION[studentinfo]['first_name'];
$arrlogin = array('role_id'=> $roleid ,'user_id'=>$userid);


if(!$userid || !$roleid)
{
	header('location:index.php?msg=Enter username password');
}
else
{
$onlineexam = new onlineexam();	
if(isset($_REQUEST['selected'])){
$answerselected = $_REQUEST['selected'];
}
$option = $_REQUEST['option'];
$currentseconds = $_REQUEST['seconds'];
$position = $_REQUEST['position'];
$currentquestion = $_REQUEST['currentquestion'];
$cur_nextquestion = $_REQUEST['nextquestion'];

if($_REQUEST['nexttype']=='match-the-following')
{ 
$quesarray=$_REQUEST['nextquestion'];
$strques = json_decode(stripslashes($quesarray));
$cur_nextquestion=json_decode(json_encode($strques),true);

$arrquestion = $onlineexam -> getQuestion($cur_nextquestion[0]['questionid'],$position);
}
else  if($cur_nextquestion!='')
{
	$arrquestion = $onlineexam -> getQuestion($cur_nextquestion,$position);

}

if(isset($_REQUEST['last']))
{
	$last=$_REQUEST['last'];
}

if(!$_SESSION['userexaminfo'])
{
$arrInput = array('course_id'=>$_REQUEST['CourseID'],'student_id'=>$_REQUEST['StudentID']);
$getExamDetails = $onlineexam->getexamdetails($arrInput);
	if($getExamDetails[0]['examkey'])
	$examtaken = 1;
	else
	$examtaken = 0;
	$arrInput['examtaken'] = $examtaken;
	$arrInput['assignedid'] = $getExamDetails[0]['id'];
	$durationseconds = $getExamDetails[0]['totalexamduration'];
	$arrInput['examduration'] = $durationseconds * 60;
	$arrInput['currenttiming'] = $getExamDetails[0]['currenttiming'];
	foreach($getExamDetails as $key=>$value)
	{
		$arrquestiontype[] = $value['questiontype_id'];
		$arrquestioncount[]= $value['no_of_questions'];
	}
	$_SESSION['userexaminfo'] = $arrInput;
}


$examdetails =$_SESSION['userexaminfo'];
$usertestid = $examdetails['assignedid'];
if($currentquestion!='fq')
{

	$answerselected = addslashes($answerselected);
	$currentQuestion = $currentquestion;		
	$currentQuestionType = $_SESSION['currentQuestiontype'];
	$correctAnswer = $onlineexam->getAnswer($currentQuestion);
	$correctanswer=0;
	if($answerselected == $correctAnswer->fields['answer'])
	{
		$correctanswer=1;
	}
	if($option=='NEXT')
	{

					
					if(isset($_REQUEST['matchquest'])){
					$strmatchvalue=$_REQUEST['matchquest'];
					$arrmatchquestval=explode("!~@",$strmatchvalue);

					foreach($arrmatchquestval as $arrvalue)
					{
						$correctanswer = 0;
						$arrmatchquest=explode("#@",$arrvalue);
							 $matchanswer= $arrmatchquest[0];
							 $answeredvalue=$arrmatchquest[1];
							 $matchquestionid=$arrmatchquest[2];
							 $mchquestionid=$arrmatchquest[3];
							 $mchanswerindex=$arrmatchquest[4];
					

						if($arrmatchquest[0]==$arrmatchquest[4])
						{

							$correctanswer = 1;
						}
					
				$questiontypeid=$onlineexam->getquestiontypeid(3);
				$arrexamdetails = array('assign_exam_id'=>$usertestid,'question_id'=>$mchquestionid,'question_type_id'=>$questiontypeid[0]['question_type_id'],'answers'=>$matchanswer,'mark'=>$correctanswer,'matchanswer'=>$answeredvalue);
			if($matchanswer && $mchquestionid && $usertestid)
						$insert = $onlineexam -> insertExamDetails($arrexamdetails);
					}
				$flag =0;
					}
					else
					{
						$flag = 1;
						$questiontypeid=$onlineexam->getquestiontypeid($currentQuestion);
						$arrexamdetails = array('assign_exam_id'=>$usertestid,'question_id'=>$currentQuestion,'question_type_id'=>$questiontypeid[0]['question_type_id'],'answers'=>$answerselected,'mark'=>$correctanswer,'matchanswer'=>'');

						if($currentQuestionType == 4 && $answerselected == "" )
						{}else if($usertestid) $insert = $onlineexam -> insertExamDetails($arrexamdetails);
					}

	}
}


$no_of_questions = $onlineexam -> getmatchcount($_SESSION['userexaminfo']['course_id'],$arrquestion[0]['question_type_id']);
?>


<?php

if($option=='NEXT')
{
	if($_REQUEST['nexttype']=='match-the-following')
	{
		$sqlcurrentQuestion = "update assign_exam set currentquestion='".$cur_nextquestion[0]['questionid']."',currenttiming = '".$currentseconds."' where examkey='".$_SESSION[uniqueTestKey]."'";
	$DB->Execute( $sqlcurrentQuestion );
	}
	else { 
$sqlcurrentQuestion = "update assign_exam set currentquestion='".$cur_nextquestion."', currenttiming = '".$currentseconds."' where examkey='".$_SESSION[uniqueTestKey]."'";
  $DB->Execute( $sqlcurrentQuestion );
	}
}
else
{
	$sql = "update assign_exam set currenttiming = '".$currentseconds."' where examkey='{$_SESSION[uniqueTestKey]}'";
    $DB->Execute( $sql );
}


if(isset($_REQUEST['complete']))
{
	$complete=$_REQUEST['complete'];
}
if($complete=='')
{
    if($arrquestion[0]['question_type_id']!=''){?>
<script>
$('.activebtn').removeClass('activebtn').addClass('disableBtn');
$('#<?php echo $arrquestion[0]['question_type_id'] ?>').removeClass().addClass('activebtn');
</script>
    <?php
	}
if($examdetails['examtaken'])
		{  
		$remainingsecond= $currentseconds;

			if($option  == 'CONTINUE'){

			echo "<script type='text/javascript'>

			$('.addFieldOuter').remove();

		var texttimer = \"<span class='addFieldOuter'><span id='timer'></span></span>\";

		$('#appendTimer').append(texttimer);

		$('#timer').countdown({until: {$remainingsecond}, expiryUrl: 'online_exam_complete.php',compact: true}); 

		</script>";

			}
		}

		else 
		{
			if($_SESSION['questCount']==-1 && $option != 'BACK')

			{
		echo "<script type='text/javascript'>
		$('.addFieldOuter').remove();
		var texttimer = \"<span class='addFieldOuter'><span id='timer'></span></span>\";
		$('#appendTimer').append(texttimer);
		$('#timer').countdown({until: {$examdetails['examduration']}, expiryUrl: 'online_exam_complete.php',compact: true}); 

		</script>";
			}

		}

switch($arrquestion[0]['questiontype'])
	{
		case 'multiple-choice':
				if($option == 'BACK')
				$disabled='disabled' ;
				else  $disabled='' ;
			  echo "<div class='onlineExamsBottom'><div class='questionTitle'>
		  <div class='questionTitleLeft'>".$arrquestion[0]['question_type_name']." - Question {$position} of {$no_of_questions}</div>
		  </div>
		  
		  <form name='frmQuestion' method='post'>
		  <div class='part1Content'><span>".$arrquestion[0]['question']."</span>";
		  foreach ($arrquestion[0]['choices'] as $choices ){
		echo  " <label><input type='radio' name='questAnswer' value='".$choices['answerindex']."' {$disabled} />".$choices['choice']."</label>";
			 }
		  echo "</div>";
 echo "<div class='questionTitle'>
      ";
	  if($last)
	  {
echo"<div class='questionBtnLeft'>";
echo "<input type='button' name='btnComplete'  class='btnContinue' value='Complete' class='btnrdoselected' alt='questAnswer' /></div>";
	  }
	  else
	  {
echo"<div class='questionBtnLeft'>";
echo"<div class='nextd'>
<img src='../web/images/next-btn-disable.png' width='61' height='25'  /></div>";
echo "<div class='next' style='display:none;'> <img src='../web/images/next-btnf.png' width='61' height='25' class='btnrdoselected' alt='questAnswer' /></div>";
	  echo "</div>";
	  }
	echo"
      </div>
";?>  
	  </form>
 </div>
 <?php
 break;
case 'true-false':
	echo "
<div class='onlineExamsBottom'>

<div class='questionTitle'>
		  <div class='questionTitleLeft'>".$arrquestion[0]['question_type_name']." - Question {$position} of {$no_of_questions}</div>
</div>
<form name='frmQuestion' method='post'>
      <div class='part2Content'><span>".$arrquestion[0]['question']."</span>
	  <label><input type='radio' name='questAnswer' value='True' {$disabled} />True</label>
	   <label><input type='radio' name='questAnswer' value='False' {$disabled} />False</label>
	  </div>";
echo "<div class='questionTitle'>";
if($last)
 {
echo"<div class='questionBtnLeft'> ";
echo "<input type='button' name='btnComplete'  class='btnContinue' value='Complete' class='btnrdoselected' alt='questAnswer' /></div>";
}
else
{
echo"<div class='questionBtnLeft'>";
echo"<div class='nextd'><img src='../web/images/next-btn-disable.png' width='61' height='25'/></div>";
echo "<div class='next' style='display:none;'> <img src='../web/images/next-btnf.png' width='61' height='25' class='btnrdoselected' alt='questAnswer' /></div>";
echo "</div>";
}
echo"
</form>
</div>";
break;
case 'subjective':
echo "
<div class='onlineExamsBottom'>
<div class='questionTitle'>
 <div class='questionTitleLeft'>".$arrquestion[0]['question_type_name']." - Question {$position} of {$no_of_questions}</div>
</div>
<form name='frmQuestion' method='post' >
<div class='part4Content'><span class='question'>".$arrquestion[0]['question']."</span>
<textarea name='txtAnswer' cols='50' rows='10' ></textarea>
<script>$(document).ready(function() {getckeditor();});</script>  
</div>"; 
echo "<div class='questionTitle'>";
if($last)
{
echo"<div class='questionBtnLeft'> ";
echo "<input type='button' name='btnComplete'  class='btnContinue subjectiveanswer' value='Complete' alt='txtAnswer' /></div>";	
}
else 
{
echo"<div class='questionBtnLeft'>";
echo "<div class='next'><img src='../web/images/next-btnf.png' width='61' height='25' class='subjectiveanswer' alt='txtAnswer' /></div>";
echo "</div>";
}
echo"</div>
</form>
</div>";
break;
case 'fill-blank':
echo "
<div class='onlineExamsBottom'>
<div class='questionTitle'>
<div class='questionTitleLeft'>".$arrquestion[0]['question_type_name']." - Question {$position} of {$no_of_questions}</div></div>
<form name='frmQuestion' method='post'>
      <div class='part2Content'><span>".$arrquestion[0]['question']."</span>
	   <input type='text' name='questAnswer' value=''  class='fillquestAnswer'  autocomplete='off'  onpaste='return false'   maxlength='50'  />
	  </div>";
echo "<div class='questionTitle'>";
	   if($last)
	  {
		   echo " <div class='questionBtnLeft'>";
		   echo "<input type='button' name='btnComplete'  class='btnContinue fillAnswer' value='Complete' alt='questAnswer' /></div>";
	  }
	  else
	  {
echo"<div class='questionBtnLeft'>";
echo"<div class='nextd'><img src='../web/images/next-btn-disable.png' width='61' height='25'/></div>";
echo "<div class='next' style='display:none;'> <img src='../web/images/next-btnf.png' width='61' height='25' class='fillAnswer' alt='questAnswer' /></div>";
echo "</div>";
	  }
	echo"
</form>
</div>";
break;
case 'match-the-following':
		//if($flag)
		{

		echo "

<div class='onlineExamsBottom'>

<script type='text/javascript'>

</script>

<div class='questionTitle'>
<div class='questionTitleLeft'>".$arrquestion[0]['question_type_name']." - Question 1 of 1</div>
";
echo"
</div>
	 <div class='part2Content'>
	 <div class='questionTopTitle'>
      <ul>
      <li class='questiontitle'>question</li>
      <li class='answerTitle'>answer</li>
      <li class='correctAnswerTitle'>correct answer</li>

      </ul>

      </div>

<form action='' method='post' id='frmMatch' name='frmMatch' >

<div id='match' class='multipleChoice'>

  <ul>";
  $answercode=1;
foreach ($cur_nextquestion as $matchthefollowing){
	
	//$answer = $onlineexam -> answerforquestion ($usertestid,$matchthefollowing['correctquestionid']);

	if($option == 'MATCHBACK')
				$disabled='disabled' ;
				else  $disabled='' ;
	echo "<li id='frmMatch'>
        <div class='dynamicfields'>
        <div>
       <span class='option'>{$answercode}</span>

        <textarea title='Enter question' class='required' name='txtMatchQuestion'  cols='28' rows='3' disabled='disabled'>{$matchthefollowing[question]}</textarea>

        <textarea title='Enter answer' class='required answerBox' name='txtAddress' id={$matchthefollowing[questionid]} cols='28' rows='3' disabled='disabled'>{$matchthefollowing[answer]}</textarea>";
	if(count($cur_nextquestion) >= 10)
	$maxlength = 2;
	else $maxlength = 1;
	
   echo " <input type='input' value='' name='txtCorrectanswer[]'  id ='{$matchthefollowing[correctquestionid]}'  class='required number matchAnswer' title='Please fill the value'  maxlength='{$maxlength}' />";
    echo "</div>
     </div>
      </li>";
	  $answercode++;
	}

echo '</ul>';
echo "</div>";
if($last)
	  {
		   echo"
		   <div class='questionBtnLeft'>";
		   echo "<input type='button' name='btnComplete'  class='btnContinue' value='Complete' onclick=\"matchthefollowing('txtCorrectanswer',event);\" /></div>";
	  }
	  else
	  {
echo"<div class='questionBtnLeft'>";
echo"<div class='nextd'><img src='../web/images/next-btn-disable.png' width='61' height='25'/></div>";
echo "<div class='next' style='display:none;' > <img src='../web/images/next-btnf.png' width='61' height='25' onclick=\"matchthefollowing('txtCorrectanswer',event);\" /></div>";
echo "</div>";
}
echo "</form>";
echo "</div>";
echo "</div>";
}
 break;

	}
	$_SESSION['questCount']=$_SESSION['questCount']+1;
exit;
}
else{
if($complete==1)
{
	echo "<script type='text/javascript'>$('.addFieldOuter').remove();</script>";
	$testcomplete = $onlineexam->userTestComplete($usertestid);
	if($testcomplete)
	{
echo '<div class="onlineExamsOuter"><div class="onlineExamContinueContent">You have successfully completed the exam. The result will be published as soon as the evaluation has been completed and will be posted on your user panel. Please allow 4 to 6  weeks from completion of examination for the posting of your results.  <a href="online_exam_instruction.php"> Go Back </a>to write the another exam</div></div>';
	         unset($_SESSION['questCount']);
	         unset($_SESSION['currentQuestiontype']);
	         unset($_SESSION[ 'uniqueTestKey' ]);
	         unset($_SESSION['userexaminfo']);

	}
}
	}
	
}

/*$lastError = error_get_last();
if($lastError)
{
print_r($lastError);
exit;
}*/
?>