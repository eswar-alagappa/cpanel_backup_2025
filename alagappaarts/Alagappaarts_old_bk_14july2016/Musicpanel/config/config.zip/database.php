<?PHP

#Database settings;
/* id : check list item -5 
   Change  the database name, Username/Password for  the db 

*/
define( "DB_HOSTNAME", "localhost" );
define( "DB_USERNAME", "appaarts_alagapa" );
define( "DB_PASSWORD", "Vb2=w!,1]TJ;" );
define( "DB_DATABASE", "alagappa_music" );

?>