</div>
<div class="footerOuter">
  <div class="footer">
    <div class="footerLeft">© Alagappa Performing Arts Academy. </div>
    <div class="footerRight"><a href="http://inqtechnologies.com/" target="_blank">Powered by InQ Technologies</a></div>
  </div>
</div>
</body>
</html>