// JavaScript Documentlet appHeader = `
    <nav>
       /*navigation or other html content here*/
    </nav>
`;
document.getElementById("app-header").innerHTML = appHeader;