<div class="row col-md-12 page-banner">
	<img src="<?php echo base_url().'upload/banner/'.$slider->imgPath ?>" alt="Alagappa Admission">
</div>