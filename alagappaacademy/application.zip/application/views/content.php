
<div class="container">
	
	<!--<div class="row col-md-12 page-banner">
		<img src="http://demo30.sanjaytechnologies.net/academy-2/academy-2/images/banner/admission.jpg" alt="Alagappa Admission">
	</div>-->
	
	
	<?php
		$CI =& get_instance();
		$CI->showBanner($type) ;
	?>
	
	<?php
	
	echo $page->content;
	?>
	<!--<div class="row col-md-9 text-justify padding_inline">
		<h3 class="orangecolor inline_heading_margin_bottom">ADMISSIONS</h3>
	
		<h4>ADMISSIONS FOR THE ACADEMIC YEAR 2019-20</h4>
		
		<p>Finding the right school is all about finding the right environment for a child and we at Alagappa Academy are committed to provide a good environment for your child to learn and grow. We have classes from Pre-primary to Class X.</p><br>
		
		<h4>ADMISSION GUIDELINES:</h4>
	
		<div>
			<ul>
				<li>Parents desirous of an enriching learning experience for their wards in a healthy environment may contact our school office for admissions.</li>
				<li>The Admission forms can be purchased at our school office.</li>
				<li>Copy of birth certificate, Transfer certificate, 3 passport size photos and Copy of Aadhaar card should be submitted along with application during the process of admissions.</li>

			</ul>
		</div>
	
		<div>
			<strong>To have an effective teaching learning process, we maintain limited class strength.</strong>
		</div>
	</div>-->