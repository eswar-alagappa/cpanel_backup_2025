<div class="row col-md-3 bottom-200">
		<div class="latest_board_news">
			<div class="inner-news">	
			<h1><div class="board_title"> Online Notice Board</div></h1>
			<div class="list-wrpaaer" style="position: relative; overflow: hidden;">
				<ul class="demo2">
					<li class="news-item">Our 172 Children have appeared for IAIS.</li>
					<li class="news-item">Our Students Participated in Kamarajar - Kalvi Valarchi Nal competitions 2018.</li>
					<li class="news-item">Our Students achieved many prices in Koviloor Inter School Competitions.</li>
					<li class="news-item">Our Student won Tamilnadu State Sub - Junior & Senior Silambam.</li>
					<li class="news-item">Our Alagappa Academy student won district level CM Trophy.</li>

				</ul>
				</div>
			</div>
		</div>
		
		
		<div class="campus-infra-right">	
			<h1><div class="board_title"> Our Campus Infra</div></h1>
			<iframe src="http://www.youtube.com/embed/cTFjGlx0K4I" width="100%" height="255px" allowfullscreen frameborder="0"></iframe>
		</div>
	</div>
	
	
</div>