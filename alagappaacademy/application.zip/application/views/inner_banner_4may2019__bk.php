<div class="row col-md-12 page-banner">
	<img src="assets/images/banner/<?php echo strtolower($type).'.jpg'; ?>" alt="Alagappa Admission">
</div>