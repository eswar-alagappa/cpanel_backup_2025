<div class="slider">
<div id="jssor_1" class="slider-responsive" style="position: relative; margin: 0 auto; top: 0px; left: 0px; width: 1600px; height: 500px; overflow: hidden; visibility: hidden;">
        <!-- Loading Screen -->
        <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 1600px; height: 500px; overflow: hidden;">
		<div data-b="2" data-p="170.00" style="display: none;">
	 <img data-u="image" src="<?php echo base_url()?>assets/images/slider1.jpg" alt="Search Engine Marketing Chennai" />
	</div>			
			
     <div data-b="1" data-p="170.00" style="display: none;">
	<img data-u="image" src="<?php echo base_url()?>assets/images/slider2.jpg" alt="Search Engine Marketing Chennai"/>
	</div> 
<div data-b="1" data-p="170.00" style="display: none;">
	<img data-u="image" src="<?php echo base_url()?>assets/images/slider3.jpg" alt="Search Engine Marketing Chennai"/>
	</div> 		
	<div data-b="1" data-p="170.00" style="display: none;">
	<img data-u="image" src="<?php echo base_url()?>assets/images/slider4.jpg" alt="Search Engine Marketing Chennai"/>
	</div>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
            <!-- bullet navigator item prototype -->
            <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
        <!-- Arrow Navigator -->
        <span data-u="arrowleft" class="jssora22l" style="top:0px;left:10px;width:40px;height:58px;" data-autocenter="2"></span>
        <span data-u="arrowright" class="jssora22r" style="top:0px;right:10px;width:40px;height:58px;" data-autocenter="2"></span>
    </div>
</div>